<?php

namespace Admin\Controller;

use Common\Controller\AdminBaseController;

class ApiController extends AdminBaseController
{
    public function index(){
        if(IS_POST){
            $data = $_POST;
            $data['savetime'] = time();
            $res = M('api')->where('id=1')->save($data);
            if($res){
                $arr['code'] = 0;
                $arr['msg'] = '提交成功';
            }else{
                $arr['code'] = 1;
                $arr['msg'] = '提交失败';
            }
            $this->ajaxReturn($arr);
        }else{
            $api = M('api')->where('id=1')->find();
            $this->assign('api',$api);
            $this->display();
        }
    }

    //获取token
    public function gettoken(){
        $api = M('api')->where('id=1')->find();
        if($api['api']==''){
            $arr['code'] = 1;
            $arr['msg'] = '请先补全其他信息';
            $this->ajaxReturn($arr);die;
        }
        // $url = $api['api'] . 'login?username='.$api['username'].'&password='.$api['password'];
    $url = $api['api'].'?code=login&user='.$api['username'].'&password='.$api['password'];

    
        $content = $this->getUrl($url);
        // $content = json_decode($content,true);
        // $msg = $api['msg'];
        // if($content["msg"]=='success'){
        //     $arr['code'] = 0;
        //     $arr['msg'] = '获取成功';
        //     $arr['token'] = $content['token'];
        // }else{
        //     $arr['code'] = 1;
        //     $arr['msg'] = "获取失败，请稍后再试";
        // }
 
        if (strpos($content, 'ERROR') !== 'false'){
            $arr['code'] = 0;
            $arr['msg'] = '获取成功';
            $arr['token'] = $content;
        }else{
            $arr['code'] = 1;
             $arr['msg'] = "获取失败，请稍后再试";
        }
       // var_dump($arr);
        $this->ajaxReturn($arr);
    }

    public function getUrl($url, $header = false) {
        $ch = curl_init($url);
        curl_setopt($ch,CURLOPT_HEADER,0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //返回数据不直接输出
        curl_setopt($ch, CURLOPT_ENCODING, "gzip"); //指定gzip压缩
        //add header
        if(!empty($header)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        //add ssl support
        if(substr($url, 0, 5) == 'https') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);    //SSL 报错时使用
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);    //SSL 报错时使用
        }
        //add 302 support
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch,CURLOPT_COOKIEFILE, $this->lastCookieFile); //使用提交后得到的cookie数据
        try {
            $content = curl_exec($ch); //执行并存储结果
        } catch (\Exception $e) {
            $this->_log($e->getMessage());
        }
        $curlError = curl_error($ch);
        if(!empty($curlError)) {
            $this->_log($curlError);
        }
        curl_close($ch);
        return $content;
    }




}
