<?php

namespace Home\Controller;


use Think\Controller;

class IndexController extends Controller
{
    protected $config;
    protected $codes;
    protected $phone;
    public function __construct()
    {
        parent::__construct();
        $config = M('api')->where('id=1')->find();
        $this->config = $config;
    }


    public function index()
    {
        $config = $this->config;
        $notice = M('notice')->where('id=1')->find();
        $notice['content'] = htmlspecialchars_decode($notice['content']);
        $this->assign('config',$config);
        $this->assign('notice',$notice);
        $this->display();
    }

    //验证卡密
    public function getcode(){
        if(IS_POST){
            $code = $_POST['code'];
            $where['code'] = array('eq',$code);
            $res = M('code')->where($where)->find();
            if($res){
                if($res['status']==1){
                    $arr['code'] = 2;
                    $arr['msg'] = '卡密已经被使用';
                    $arr['sms'] = $res['sms'];
                    $arr['phone'] = $res['phone'];
                }else{
                    $arr['code'] = 0;
                    $arr['msg'] = '卡密输入正确，正在获取手机号';
                }
            }else{
                $arr['code'] = 1;
                $arr['msg'] = '卡密不存在';
            }
            $this->ajaxReturn($arr);
        }
    }

    //获取手机号
    public function getphone(){
        if(IS_POST) {
            $config = $this->config;
            $codes = $_POST['code'];
            $api = $config['api']."?code=getPhone&token=".$config['token'];
      
           // $api = $config['api'].'getPhone?token='.$config['token'].'&sid='.$config['project'].'&numsize=1';
            $res = $this->phone($api);
            $s= $res;
        
           if(strpos($res, 'ERROR') !== 'false'){
                $arr['code'] = 0;
                $arr['phone'] ="'".$res."'";
                $arr['msg'] = "获取成功";
            }else{
                $arr['code'] = 1;
                $arr['msg'] = "获取号码失败";
            }
            $this->ajaxReturn($arr);
        }
    }

    public function phone($api){
        $config = $this->config;
        $res = $this->getUrl($api);
               
       if(strpos($res, 'ERROR') !== false){
            sleep(5);
            $this->phone($api);
        }else{
            return $res;
        }
    }

    public function getcodes(){
        if(IS_POST){
            $config = $this->config;
            $codes = $_POST['code'];
            $phone = $_POST['phone'];
            $this->codes = $codes;
            $this->phone = $phone;
            //$api = $config['api']."getMessage?token=".$config['token']."&sid=".$config['project']."&".$config['phone']."=".$phone;
            //$api = $config['api'].'getMessage?token='.$config['token'].'&sid='.$config['project'].'&phone='.$phone;
          $api = $config['api'].'?code=getMsg&token='.$config['token'].'&keyWord='.$config['project'].'&phone='.$phone;
            $this->scode($api);
        }
    }
    public function scode($api){
        $config = $this->config;
        $res = $this->getUrl($api);
   
        if(strpos($res, '尚未收到') == 'false'){
            
            sleep(10);
            $this->scode($api);
        }elseif(strpos($res, 'ERROR') !== false){
            $arr['code'] = 1;
            $arr['msg'] = "'".$res."'";
        }else{
            $arr['code'] = 0;
            $res=substr($res,strripos($res,"【"));
            //$res = substr($number,strripos($res,"/")+1);
            $arr['sms'] = $res;
            $arr['msg'] = "获取成功";
        }
        $this->ajaxReturn($arr);
    } 

    //拉黑手机号
    public function black(){
        $config = $this->config;
        $phone = $this->phone;
        // $api = $config['api']."addBlacklist?token=".$config['token']."&sid=".$config['project']."&".$config['phone']."=".$phone;
        $api = $config['api'].'addBlacklist?token='.$config['token'].'&sid='.$config['project'].'&phone='.$phone;
        $this->getUrl($api);
    }
  

    //get请求
    public function getUrl($url, $header = false) {
        $ch = curl_init($url);
        curl_setopt($ch,CURLOPT_HEADER,0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //返回数据不直接输出
        curl_setopt($ch, CURLOPT_ENCODING, "gzip"); //指定gzip压缩
        //add header
        if(!empty($header)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        //add ssl support
        if(substr($url, 0, 5) == 'https') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);    //SSL 报错时使用
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);    //SSL 报错时使用
        }
        //add 302 support
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch,CURLOPT_COOKIEFILE, $this->lastCookieFile); //使用提交后得到的cookie数据
        try {
            $content = curl_exec($ch); //执行并存储结果
        } catch (\Exception $e) {
            $this->_log($e->getMessage());
        }
        $curlError = curl_error($ch);
        if(!empty($curlError)) {
            $this->_log($curlError);
        }
        curl_close($ch);
        return $content;
    }



}